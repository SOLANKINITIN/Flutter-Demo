package com.example.ragnar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
