import 'package:ragnar/Screens/acknowledgements_screen.dart';
import 'package:ragnar/Screens/feedback_screen.dart';
import 'package:ragnar/Screens/navigation/navigator_screens.dart';
import 'package:ragnar/Screens/resetpassword_screen.dart';
import 'package:ragnar/Screens/home_screen.dart';
import 'package:ragnar/Screens/intro_screen.dart';
import 'package:ragnar/Screens/signin_screen.dart';
// import 'package:ragnar/Screens/location_screen.dart';
import 'package:ragnar/Screens/messages_screen.dart';
// import 'package:ragnar/Screens/notification_screen.dart';
import 'package:ragnar/Screens/help_screen.dart';
import 'package:ragnar/Screens/privacy_policy_screen.dart';
import 'package:ragnar/Screens/signup_screen.dart';
import 'package:ragnar/Screens/splash_screen.dart';
import 'package:ragnar/Screens/staff_swat_pin_screen.dart';
import 'package:ragnar/setting_screen.dart';

final appRoute = {
  '/': (context) => NavigatorScreen(),
  '/home': (context) => HomeScreen(),
  '/splash': (context) => SplashScreen(),
  '/intro': (context) => IntroScreen(),
  '/signin': (context) => SigninScreen(),
  '/signup': (context) => SignupScreen(),
  '/forgetpassword': (context) => ResetPasswordScreen(),
  // '/location': (context) => LocationScreen(),
  // '/notification': (context) => NotificationScreen(),
  '/privacypolicy': (context) => PrivacyPolicyScreen(),
  '/acknowledgements': (context) => Acknowledgements(),
  '/help': (context) => HelpScreen(),
  '/feedback': (context) => FeedbackScreen(),
  '/setting': (context) => SettingScreen(),
  '/staffswatpin': (context) => StaffSwatPinScreen(),
  '/messages': (context) => MessagesScreen(),
};
