// import 'package:flutter/material.dart';
// import 'package:ragnar/Screens/home_screen.dart';
// import 'package:ragnar/Screens/intro_screen.dart';
// import 'dart:async';
// import 'package:splashscreen/splashscreen.dart';

// class Splash extends StatelessWidget {
//   const Splash({Key key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return SplashScreen(
//       seconds: 60,
//       navigateAfterSeconds: IntroScreen(),
//       // title: Text('Ragnar'),
//       image: Image.asset('assets/images/ragnar.png'),
//       loadingText: Text('Loading...'),
//       photoSize: 80,
//       loaderColor: Colors.orangeAccent,
//     );
//   }
// }

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:ragnar/Screens/intro_screen.dart';

class SplashScreen extends StatefulWidget {
  SplashScreen({Key key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  AnimationController _controller;
  Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 4),
      vsync: this,
    )..repeat(
        reverse: false,
      );
    _animation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOut,
    );
    // _controller.addListener(() {
    //   setState(() =>
    //     Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (BuildContext context) => IntroScreen()
    //     ))
    //   );
    // });
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Timer(
        Duration(seconds: 4),
        () => Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => IntroScreen())));
    return Scaffold(
      body: Center(
        child: ScaleTransition(
          scale: _animation,
          child: const Padding(
            padding: EdgeInsets.all(8),
            child: Image(image: AssetImage('assets/images/ragnar.png')),
          ),
        ),
      ),
    );
  }
}
