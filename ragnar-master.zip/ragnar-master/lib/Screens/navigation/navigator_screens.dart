import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:ragnar/Screens/components/messages_tabbar.dart';
import 'package:ragnar/Screens/home_screen.dart';

class NavigatorScreen extends StatefulWidget {
  @override
  _NavigatorScreenState createState() => _NavigatorScreenState();
}

const Color shrinePink400 = Color(0xFFEAA4A4);
const Color shrineBrown900 = Color(0xFF442B2D);
const Color shrineBrown600 = Color(0xFF7D4F52);
const Color shrineErrorRed = Color(0xFFC5032B);

class _NavigatorScreenState extends State<NavigatorScreen> {
  int _page = 0;
  GlobalKey _bottomNavigationKey = GlobalKey();

  MessagesTabBar messagesTabBar = MessagesTabBar();
  HomeScreen homeScreen = HomeScreen();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Home"),
        ),
        drawer: Drawer(
          child: ListView(
            children: [
              ListTile(
                title: Text("Home"),
                leading: Icon(Icons.home),
                trailing: Icon(Icons.navigate_next, color: Colors.black),
                onTap: () => Navigator.pushNamed(context, '/'),
              ),
              ListTile(
                  title: Text("Setting"),
                  leading: Icon(Icons.settings),
                  trailing: Icon(Icons.navigate_next, color: Colors.black),
                  onTap: () => Navigator.pushNamed(context, '/setting')),
            ],
          ),
        ),
        bottomNavigationBar: CurvedNavigationBar(
          key: _bottomNavigationKey,
          index: 0,
          height: 50.0,
          items: <Widget>[
            Icon(Icons.home, size: 30),
            Icon(Icons.message, size: 30),
            Icon(Icons.person, size: 30),
            Icon(Icons.photo_library, size: 30),
          ],
          color: Colors.white,
          buttonBackgroundColor: Colors.white,
          backgroundColor: _page == 0
              ? shrinePink400
              : _page == 1
                  ? shrineBrown900
                  : _page == 2
                      ? shrineBrown600
                      : _page == 3
                          ? shrineErrorRed
                          : null,
          animationCurve: Curves.easeInOut,
          animationDuration: Duration(milliseconds: 600),
          onTap: (index) {
            setState(() {
              _page = index;
            });
          },
          letIndexChange: (index) => true,
        ),
        body: Container(
          child: _page == 0
              ? homeScreen
              : _page == 1
                  ? messagesTabBar
                  : _page == 2
                      ? messagesTabBar
                      : null,
        ));
  }
}
