import 'package:flutter/material.dart';

class MessagesScreen extends StatefulWidget {
  @override
  _MessagesScreenState createState() => _MessagesScreenState();
}

class _MessagesScreenState extends State<MessagesScreen>
    with SingleTickerProviderStateMixin {
  TabController _tabController;

  @override
  void initState() {
    _tabController = new TabController(length: 2, vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TabBar(
              unselectedLabelColor: Colors.black,
              labelColor: Colors.red,
              tabs: [
                Tab(
                text: '1st tab'
                ),
                Tab(
                text: '2st tab'
                ),
              ],
              controller: _tabController,
              indicatorSize: TabBarIndicatorSize.tab,
              ),
              Expanded(child: TabBarView(
                children: [
                  Container(
                    child: Center(child: Text('people'))),
                    Text('person')
                ],
                controller: _tabController,
                ))
          ],
        ),
      ),
    );
  }
}
