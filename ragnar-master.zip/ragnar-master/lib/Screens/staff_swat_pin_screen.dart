import 'package:flutter/material.dart';
import 'package:passcode/passcode.dart';

class StaffSwatPinScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Staff/SWAT Pin'),
      ),
      body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Center(
            child: Container(
              padding: EdgeInsets.all(25),
                child: Text("Enter Passcode for \nStaff/SWAT Photo access", 
                  style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ),
            )),
          PasscodeTextField(
              totalCharacters: 6,
              passcodeType: PasscodeType.number,
              borderColor: Colors.black,
              onTextChanged: (passcode) {
                print(passcode);
              }),
        ],
      )),
    );
  }
}
