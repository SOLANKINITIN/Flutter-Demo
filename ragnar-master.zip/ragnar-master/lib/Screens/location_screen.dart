import 'package:flutter/material.dart';

class LocationScreen extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Location'),
      ),
      body: Container(
        child: Center(
          child: Text("Location Page")
          ),
      ),
    );
  }
}