import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class SignupScreen extends StatefulWidget {
  SignupScreen({Key key}) : super(key: key);

  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  TextStyle style = TextStyle(fontFamily: 'Montserrat', fontSize: 18.0);

  Widget _firstNameField(){
    return TextField(
      style: style,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: -5),
        labelText: 'First Name',
        suffixIcon: Icon(Icons.person),
      ),
    );
  }

  Widget _lastNameField(){
    return TextField(
      style: style,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: -5),
        labelText: 'Last Name',
        suffixIcon: Icon(Icons.person),
      ),
    );
  }

  Widget _emailField(){
    return TextField(
      style: style,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: -5),
        labelText: 'Email',
        suffixIcon: Icon(Icons.email),
      ),
    );
  }

  Widget _dateOfBirthField(){
    return TextField(
      style: style,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: -5),
        labelText: 'Date Of Birth',
        suffixIcon: Icon(Icons.calendar_today),
      ),
    );
  }  
  
  Widget _passwordField(){
    return TextField(
      obscureText: true,
      style: style,
      decoration: InputDecoration(
          contentPadding: EdgeInsets.symmetric(vertical: -5),
          labelText: "Password", 
          suffixIcon: Icon(Icons.vpn_key),
          ),
    );
  }

  Widget _confirmPasswordField(){
    return TextField(
      obscureText: true,
      style: style,
      decoration: InputDecoration(
          contentPadding: EdgeInsets.symmetric(vertical: -5),
          labelText: "Confirm Password", 
          suffixIcon: Icon(Icons.vpn_key),
          ),
    );
  }

  Widget _createAccountButton(){
     return Material(
      elevation: 5.0,
      borderRadius: BorderRadius.circular(5.0),
      color: Color.fromRGBO(255, 91, 53, 1),
      child: MaterialButton(
        minWidth: MediaQuery.of(context).size.width,
        onPressed: () {},
        child: Text("Create Account",
            textAlign: TextAlign.center,
            style: style.copyWith(
                color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }
  
  Widget _guestButton(){
    return RichText(
      text: TextSpan(
        text: "Continue as guest",
        style: TextStyle(color: Colors.blue),
        recognizer: TapGestureRecognizer()
          ..onTap = () => Navigator.pushNamed(context, '/'),
      ),
    );
  }

  Widget _signinButton() {
    return RichText(
      text: TextSpan(
        text: "Have an account? ",
        style: TextStyle(color: Colors.black),
        children: <TextSpan>[
          TextSpan(
            text: "Sign In",
            style: TextStyle(color: Colors.deepOrangeAccent, fontWeight: FontWeight.bold),
            recognizer: TapGestureRecognizer()
              ..onTap = () => Navigator.pushNamed(context, '/signin'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
          body: Container(
            padding: EdgeInsets.symmetric(horizontal: 20),
         child: GestureDetector(
            onTap: () {
            FocusScope.of(context).requestFocus(FocusNode());
          },
            child: SingleChildScrollView(
              child: Column(
               mainAxisAlignment: MainAxisAlignment.center,
               crossAxisAlignment: CrossAxisAlignment.center,
               children: [
                 SizedBox(height: 50),
                 Text('Sign Up', style: TextStyle(color: Colors.deepOrangeAccent, fontSize: 20, fontWeight: FontWeight.bold)),
                 SizedBox(height: 10),
                 _firstNameField(),
                 SizedBox(height: 10),
                 _lastNameField(),
                 SizedBox(height: 10),
                 _emailField(),
                 SizedBox(height: 10),
                 _dateOfBirthField(),
                 SizedBox(height: 10),
                 _passwordField(),
                 SizedBox(height: 10),
                 _confirmPasswordField(),
                 SizedBox(height: 20),
                 _createAccountButton(),
                 SizedBox(height: 20),
                 _signinButton(),
                 SizedBox(height: 10),
                 _guestButton(),
               ],
               ),
            ),
         ),
      ),
    );
  }
}


// class SignupScreen extends StatelessWidget {
//   const SignupScreen({Key key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       // constraints: BoxConstraints.expand(),
//       decoration: BoxDecoration(
//         image: DecorationImage(
//           image: AssetImage('assets/images/back.jpg'),
//           fit: BoxFit.cover,
//         )
//       ),
//       child: null,
//     );
//   }
// }

// class SignupScreen extends StatefulWidget {
//   SignupScreen({Key key}) : super(key: key);

//   @override
//   _SignupScreenState createState() => _SignupScreenState();
// }

// class _SignupScreenState extends State<SignupScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       constraints: BoxConstraints.expand(),
//         decoration: BoxDecoration(
//               image: DecorationImage(
//                 // image: AssetImage('/assets/images/back.jpg'),
//                 image: NetworkImage('https://mir-s3-cdn-cf.behance.net/project_modules/disp/496ecb14589707.562865d064f9e.png'),
//                 fit: BoxFit.cover
//               ),
//             ),
//     );
//   }
// }