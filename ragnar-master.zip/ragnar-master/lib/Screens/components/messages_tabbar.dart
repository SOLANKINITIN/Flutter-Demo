import 'package:flutter/material.dart';

class MessagesTabBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        initialIndex: 0,
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            toolbarHeight: 50,
            leadingWidth: 20,
            backgroundColor: Colors.white,
            bottom: TabBar(
              indicatorColor: Colors.deepOrangeAccent,
              labelColor: Colors.black,
              tabs: [
                Tab(
                  text: 'Race Updates',
                ),
                Tab(
                  text: 'Team Chat',
                ),
              ],
            ),
          ),
          body: TabBarView(
            children: [
              Container(
                color: Color(0xFF442B2D),
              ),
              Container(
                color: Color(0xFF442B2D),
              )
            ],
          ),
        ),
      ),
    );
  }
}
