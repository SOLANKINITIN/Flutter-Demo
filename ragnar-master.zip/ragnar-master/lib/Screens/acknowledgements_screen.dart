import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class Acknowledgements extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    TextStyle defaultStyle = TextStyle(color: Colors.black54, fontSize: 15.0);
    TextStyle linkStyle = TextStyle(color: Colors.blueAccent);
    
    _launchLicenseURL() async {
      const url = 'https://icons8.com/license';
      if (await canLaunch(url)) {
        await launch(url);
      } else {
        throw 'Could not launch $url';
      }
      }

      _launchLawURL() async {
      const url = 'https://icons8.com/web-app/2112/law';
      if (await canLaunch(url)) {
        await launch(url);
      } else {
        throw 'Could not launch $url';
      }
      }
      
      _launchUpdatesURL() async {
      const url = 'https://icons8.com/web-app/25224/Available-Updates';
      if (await canLaunch(url)) {
        await launch(url);
      } else {
        throw 'Could not launch $url';
      }
      }

      _launchBulletproofURL() async {
      const url = 'htps://icons8.com/web-app/12478/bulletproof-vest';
      if (await canLaunch(url)) {
        await launch(url);
      } else {
        throw 'Could not launch $url';
      }
      }

      // _launchPresentationURL() async {
      // const url = 'https://icons8.com/web-app/2723/presentation';
      // if (await canLaunch(url)) {
      //   await launch(url);
      // } else {
      //   throw 'Could not launch $url';
      // }
      // }

      
      


    return Scaffold(
      appBar: AppBar(
        title: Text('Acknowledgements'),
      ),
      body: Container(
        child: ListView(
          children: <Widget>[
            Container(
                child: RichText(
              text: TextSpan(style: defaultStyle, children: [
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Linking information:- "),
                TextSpan(
                    text: '(https://icons8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Rules & Regulations: No apparent licensing issue:- "),
                TextSpan(
                    text: '(https://icons8.com/web-app/2112/law)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLawURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Updates:- "),
                TextSpan(
                    text: '(https://icons8.com/web-app/25224/Available-Updates)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchUpdatesURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Available updates icon by Icons8Safety Vest: No apparent licensing issue:- "),
                TextSpan(
                    text: '(htps://icons8.com/web-app/12478/bulletproof-vest)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchBulletproofURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Safety Briefing: No apparent Licensing issue "),
                TextSpan(
                    text: '(https://icons8.com/web-app/2723/presentation)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Wild Life:- "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Night Time Running (flashlight): No apparent licensing issue "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Schedule: No apparent licensing issue "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "No Parking: No apparent licensing issue "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Camping Tent: No apparent licensing issue "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Packet Pickup (Globe): No apparent licensing issue "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Hold Times (Runner):- "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Running icon credits Hotel: No apparent licensing issue "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "No Parking: No apparent licensing issue "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Phone: No apparent licensing issue "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Hamburger icon (food):- "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Shower icon: No apparent licensing issue "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Fork&Knife icon: No apparent licensing issue "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Shopping Cart: No apparent licensing issue "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Sleep icon: No apparent licensing issue "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Doctor Bag icon:- "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Permission (Noun Project): overview "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Charity icon: Charity by Jason Jo from the Noun Project "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Partnership icon: partnership by Artem Kovyazin from the Noun Project "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
                WidgetSpan(child: Icon(Icons.forward, size: 20,)),
                TextSpan(text: "Download icon: download cloud by Roman Shvets from the Noun Project "),
                TextSpan(
                    text: '(https://icon8.com/license)\n',
                    style: linkStyle,
                    recognizer: TapGestureRecognizer()
                      ..onTap = _launchLicenseURL),
              ]),
            ))
          ],
        ),
      ),
    );
  }
}
