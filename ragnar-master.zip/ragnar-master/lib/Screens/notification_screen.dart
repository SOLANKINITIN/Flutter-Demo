import 'package:flutter/material.dart';

class NotificationScreen extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Notification'),
      ),
      body: Container(
        child: Center(
          child: Text("Notification Page")
          ),
      ),
    );
  }
}