import 'package:flutter/material.dart';

class ResetPasswordScreen extends StatefulWidget {
  ResetPasswordScreen({Key key}) : super(key: key);

  @override
  _ResetPasswordScreenState createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  TextStyle style = TextStyle(fontFamily: 'Montserrat', fontSize: 18.0);

  Widget _backButton() {
    return Align(
        child: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () => Navigator.pushNamed(context, '/signin')),
        alignment: Alignment.topLeft);
  }

  Widget _emailField() {
    return TextField(
      style: style,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: -5),
        labelText: 'Email',
        suffixIcon: Icon(Icons.email),
      ),
    );
  }

  Widget _newPasswordField() {
    return TextField(
      obscureText: true,
      style: style,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: -5),
        labelText: "New Password",
        suffixIcon: Icon(Icons.vpn_key),
      ),
    );
  }

  Widget _confirmPasswordField() {
    return TextField(
      obscureText: true,
      style: style,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: -5),
        labelText: "Confirm Password",
        suffixIcon: Icon(Icons.vpn_key),
      ),
    );
  }

  Widget _forgetPasswordButon() {
    return Material(
      elevation: 5.0,
      borderRadius: BorderRadius.circular(5.0),
      color: Color.fromRGBO(255, 91, 53, 1),
      child: MaterialButton(
        minWidth: MediaQuery.of(context).size.width,
        onPressed: () {},
        child: Text("Reset Password",
            textAlign: TextAlign.center,
            style: style.copyWith(
                color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.white,
      body: new Container(
          child: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              SizedBox(height: 30),
              _backButton(),
              SizedBox(height: 10),
              Text(
                'Reset Password',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              _emailField(),
              SizedBox(height: 20),
              _newPasswordField(),
              SizedBox(height: 20),
              _confirmPasswordField(),
              SizedBox(height: 30),
              _forgetPasswordButon(),
            ],
          ),
        ),
      )),
    );
  }
}
