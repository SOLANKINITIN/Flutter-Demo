import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:ragnar/Screens/common/clipper_screen.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';

class SigninScreen extends StatefulWidget {
  SigninScreen({Key key}) : super(key: key);

  @override
  _SigninScreenState createState() => _SigninScreenState();
}

class _SigninScreenState extends State<SigninScreen> {
  TextStyle style = TextStyle(fontFamily: 'Montserrat', fontSize: 18.0);

  Widget _emailField() {
    return TextField(
      style: style,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: -5),
        labelText: 'Email',
        suffixIcon: Icon(Icons.email),
      ),
    );
  }

  Widget _passwordField() {
    return TextField(
      obscureText: true,
      style: style,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: -5),
        labelText: "Password",
        suffixIcon: Icon(Icons.vpn_key),
      ),
    );
  }

  Widget _forgetPassword() {
    return Align(
      alignment: Alignment.topRight,
      child: Container(
        child: RichText(
          text: TextSpan(
            text: 'Forgot Password?',
            style: TextStyle(color: Colors.black54),
            recognizer: TapGestureRecognizer()
              ..onTap = () => Navigator.pushNamed(context, '/forgetpassword'),
          ),
        ),
      ),
    );
  }

  Widget _loginButon() {
    return Material(
      elevation: 5.0,
      borderRadius: BorderRadius.circular(5.0),
      color: Color.fromRGBO(255, 91, 53, 1),
      child: MaterialButton(
        minWidth: MediaQuery.of(context).size.width,
        onPressed: () {},
        child: Text("Sign In",
            textAlign: TextAlign.center,
            style: style.copyWith(
                color: Colors.white, fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _signupButton() {
    return RichText(
      text: TextSpan(
        text: "Don't have an account? ",
        style: TextStyle(color: Colors.black),
        children: <TextSpan>[
          TextSpan(
            text: "Create One",
            style: TextStyle(
                color: Colors.deepOrangeAccent, fontWeight: FontWeight.bold),
            recognizer: TapGestureRecognizer()
              ..onTap = () => Navigator.pushNamed(context, '/signup'),
          ),
        ],
      ),
    );
  }

  Widget _socialLogin() {
    return Material(
      child: SignInButton(
        Buttons.Google,
        text: "Sign In With Google",
        onPressed: () {},
      ),
    );
  }

  Widget _guestButton() {
    return RichText(
      text: TextSpan(
        text: "Continue as guest",
        style: TextStyle(color: Colors.blue),
        recognizer: TapGestureRecognizer()
          ..onTap = () => Navigator.pushNamed(context, '/'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;

    return Scaffold(
      body: Container(
        height: height,
        color: Colors.white,
        child: GestureDetector(
          onTap: () {
            FocusScope.of(context).requestFocus(FocusNode());
          },
          child: Stack(
            children: <Widget>[
              Positioned(child: ClippingBackground()),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      SizedBox(height: height * .22),
                      Text(
                        ' Sign In',
                        style: TextStyle(
                            fontSize: 25,
                            fontWeight: FontWeight.bold,
                            color: Colors.deepOrangeAccent),
                      ),
                      // Image.asset('assets/images/ragnar.png',height: 80, width: 80,),
                      SizedBox(height: 30),
                      _emailField(),
                      SizedBox(height: 10),
                      _passwordField(),
                      SizedBox(height: 10),
                      _forgetPassword(),
                      SizedBox(height: 10),
                      _loginButon(),
                      SizedBox(height: 15),
                      _signupButton(),
                      SizedBox(height: 15),
                      _socialLogin(),
                      SizedBox(height: 15),
                      _guestButton(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
