import 'package:flutter/material.dart';

class FeedbackScreen extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Feedback'),
      ),
      body: Container(
        child: Center(
          child: Text("Feedback Page")
          ),
      ),
    );
  }
}