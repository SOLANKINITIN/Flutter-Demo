import 'package:flutter/material.dart';
import 'package:intro_slider/intro_slider.dart';
import 'package:intro_slider/slide_object.dart';

class IntroScreen extends StatefulWidget {
  IntroScreen({Key key}) : super(key: key);

  @override
  _IntroScreenState createState() => _IntroScreenState();
}

class _IntroScreenState extends State<IntroScreen> {
  List<Slide> slides = new List();

  @override
  void initState() {
    super.initState();

    slides.add(
      new Slide(
        description:
            "Navigate your race and find all details you need for your Ragnar experience",
        pathImage: "assets/images/home_white.png",
        backgroundColor: Color(0xfff5a623),
      ),
    );
    slides.add(
      new Slide(
        description:
            "Communicate with your teammates and get notifications from Ragnar for your race",
        pathImage: "assets/images/messages_white.png",
        backgroundColor: Color(0xff203152),
      ),
    );
    slides.add(
      new Slide(
        description: "See your profile and all your Ragnar Accomplishments",
        pathImage: "assets/images/person_white.png",
        backgroundColor: Color(0xff9932CC),
      ),
    );
    slides.add(
      new Slide(
        description:
            "Look back and reminisce on the good times with the photo platform",
        pathImage: "assets/images/photo_album_white.png",
        backgroundColor: Colors.redAccent,
      ),
    );
  }

  void onDonePress() {
    Navigator.pushNamed(context, '/signin');
  }

  @override
  Widget build(BuildContext context) {
    return new IntroSlider(
      slides: slides,
      onDonePress: onDonePress,
      colorDot: Colors.grey,
      colorActiveDot: Colors.white,
    );
  }
}
