import 'package:flutter/material.dart';

class SettingScreen extends StatefulWidget {
  // SettingScreen({Key key}) : super(key: key);

  @override
  _SettingScreenState createState() => _SettingScreenState();
}

class _SettingScreenState extends State<SettingScreen> {
  bool isSwitchedLocation = false;
  bool isSwitchedNotification = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Settings"),
        // backgroundColor: Colors.white,
      ),
      body: ListView(
        children: [
          ListTile(
            title: Text("Location"),
            leading: Icon(Icons.location_pin),
            trailing: Switch(
                value: isSwitchedLocation,
                onChanged: (value) {
                  setState(() {
                    isSwitchedLocation = value;
                    print(isSwitchedLocation);
                  });
                }),
            // Icon(Icons.navigate_next, color: Colors.black),
            // onTap: () => Navigator.pushNamed(context, '/location'),
          ),
          Divider(),
          ListTile(
            title: Text("Notification"),
            leading: Icon(Icons.notifications),
            trailing:Switch(
                value: isSwitchedNotification,
                onChanged: (value) {
                  setState(() {
                    isSwitchedNotification = value;
                    print(isSwitchedNotification);
                  });
                }), 
            // Icon(Icons.navigate_next, color: Colors.black),
            // onTap: () => Navigator.pushNamed(context, '/notification'),
          ),
          Divider(),
          ListTile(
            title: Text("Privacy Policy"),
            leading: Icon(Icons.policy),
            trailing: Icon(Icons.navigate_next, color: Colors.black),
            onTap: () => Navigator.pushNamed(context, '/privacypolicy'),
          ),
          Divider(),
          ListTile(
            title: Text("Acknowledgements"),
            leading: Icon(Icons.list),
            trailing: Icon(Icons.navigate_next, color: Colors.black),
            onTap: () => Navigator.pushNamed(context, '/acknowledgements'),
          ),
          Divider(),
          ListTile(
            title: Text("Help"),
            leading: Icon(Icons.help_center),
            trailing: Icon(Icons.navigate_next, color: Colors.black),
            onTap: () => Navigator.pushNamed(context, '/help'),
          ),
          Divider(),
          ListTile(
            title: Text("Feedback"),
            leading: Icon(Icons.feedback),
            trailing: Icon(Icons.navigate_next, color: Colors.black),
            onTap: () => Navigator.pushNamed(context, '/feedback'),
          ),
          Divider(),
          ListTile(
              title: Text("Staff/SWAT Pin"),
              leading: Icon(Icons.vpn_key),
              trailing: Icon(Icons.navigate_next, color: Colors.black),
              onTap: () => Navigator.pushNamed(context, '/staffswatpin')),
          Divider(),
          ListTile(
              title: Text("Logout"),
              leading: Icon(Icons.logout),
              // trailing: Icon(Icons.navigate_next, color: Colors.black),
              onTap: () => Navigator.pushNamed(context, '/')),
        ],
      ),
    );
  }
}

// class SettingScreen extends StatelessWidget {

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Settings"),
//         // backgroundColor: Colors.white,
//       ),
//       body: ListView(
//         children: [
//           ListTile(
//             title: Text("Location"),
//             leading: Icon(Icons.location_pin),
//             trailing: Icon(Icons.navigate_next, color: Colors.black),
//             onTap: () => Navigator.pushNamed(context, '/location'),
//           ),
//           Divider(),
//           ListTile(
//             title: Text("Notification"),
//             leading: Icon(Icons.notifications),
//             trailing: Icon(Icons.navigate_next, color: Colors.black),
//             onTap: () => Navigator.pushNamed(context, '/notification'),
//           ),
//           Divider(),
//           ListTile(
//             title: Text("Privacy Policy"),
//             leading: Icon(Icons.policy),
//             trailing: Icon(Icons.navigate_next, color: Colors.black),
//             onTap: () => Navigator.pushNamed(context, '/privacypolicy'),
//           ),
//           Divider(),
//           ListTile(
//             title: Text("Acknowledgements"),
//             leading: Icon(Icons.list),
//             trailing: Icon(Icons.navigate_next, color: Colors.black),
//             onTap: () => Navigator.pushNamed(context, '/acknowledgements'),
//           ),
//           Divider(),
//           ListTile(
//             title: Text("Help"),
//             leading: Icon(Icons.help_center),
//             trailing: Icon(Icons.navigate_next, color: Colors.black),
//             onTap: () => Navigator.pushNamed(context, '/help'),
//           ),
//           Divider(),
//           ListTile(
//             title: Text("Feedback"),
//             leading: Icon(Icons.feedback),
//             trailing: Icon(Icons.navigate_next, color: Colors.black),
//             onTap: () => Navigator.pushNamed(context, '/feedback'),
//           ),
//           Divider(),
//           ListTile(
//             title: Text("Staff/SWAT Pin"),
//             leading: Icon(Icons.vpn_key),
//             trailing: Icon(Icons.navigate_next, color: Colors.black),
//             onTap: () => Navigator.pushNamed(context, '/staffswatpin')
//           ),
//           Divider(),
//           ListTile(
//             title: Text("Logout"),
//             leading: Icon(Icons.logout),
//             // trailing: Icon(Icons.navigate_next, color: Colors.black),
//             onTap: () => Navigator.pushNamed(context, '/')
//           ),

//         ],
//       ),
//     );
//   }
// }
