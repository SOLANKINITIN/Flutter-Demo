import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import 'routes.dart';

final RouteObserver<PageRoute> routeObserver = RouteObserver<PageRoute>();

class MyApp extends StatelessWidget {
  // const App({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Ragnar',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/splash',
      navigatorObservers: [routeObserver],
      routes: appRoute,
    );
  }
}
